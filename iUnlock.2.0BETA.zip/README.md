 •••• Magisk Module •••
 
  All Script Written by : MohammedAlbasheer or Taylo

##### Note: My Mod Not responsible of any banned you get This Mod is 100% Safe

##### If you don't wanna get banned of any game just follow my steps



1) - go to magisk manager then Go to settings then Go to hide magisk manager 

2) - in settings hide magisk enable it and hide all games like pubg, cod, etc.





#### Note: This Module is Encrypted so don't even try play with it.
### Version: 1.0

changelog: V1.0
1- Added 2 new games (Dead by Daylight, Mobile Legends, Arena of Valor, and more 3 games too)
2- Change flashing UI and fix Flashing time
3- Add fps booster inside 
4- Fix Some devices that my mod not working with it
################
Changelog: V2.0BETA 
1-ADD TURBO TO PUBG AND FIX 90FPS
2-FPS BOOSTER ENGINE XI AVAILABLE NOW
###########
 